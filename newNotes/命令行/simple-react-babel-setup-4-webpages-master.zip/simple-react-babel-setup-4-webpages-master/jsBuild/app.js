"use strict";

var HelloMessage = React.createClass({
	displayName: "HelloMessage",

	render: function render() {
		return React.createElement(
			"div",
			null,
			"Hello ",
			this.props.name
		);
	}
});

ReactDOM.render(React.createElement(HelloMessage, { name: "John" }), document.getElementById('app'));